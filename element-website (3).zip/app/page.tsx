"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import LoadingCube from "@/components/loading-cube"

interface User {
  id: string
  username: string
  password: string
  isAdmin: boolean
  createdAt: string
}

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Initialize admin user if not exists
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const adminExists = users.find((user: User) => user.username === "A-ADMIN")

    if (!adminExists) {
      const adminUser: User = {
        id: "admin-001",
        username: "A-ADMIN",
        password: "10101010",
        isAdmin: true,
        createdAt: new Date().toISOString(),
      }
      users.push(adminUser)
      localStorage.setItem("users", JSON.stringify(users))
    }

    // Check if user is already logged in
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      setTimeout(() => {
        router.push("/dashboard")
      }, 3000)
    } else {
      setTimeout(() => setIsLoading(false), 3000)
    }
  }, [router])

  const handleLogin = () => {
    const users: User[] = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u) => u.username === username && u.password === password)

    if (user) {
      localStorage.setItem("currentUser", JSON.stringify(user))
      setIsLoading(true)
      setTimeout(() => {
        router.push("/dashboard")
      }, 3000)
      toast({
        title: "ورود موفق",
        description: "به سایت خوش آمدید",
      })
    } else {
      toast({
        title: "خطا",
        description: "نام کاربری یا رمز عبور اشتباه است",
        variant: "destructive",
      })
    }
  }

  const handleRegister = () => {
    if (password !== confirmPassword) {
      toast({
        title: "خطا",
        description: "رمز عبور و تکرار آن یکسان نیستند",
        variant: "destructive",
      })
      return
    }

    const users: User[] = JSON.parse(localStorage.getItem("users") || "[]")
    const userExists = users.find((u) => u.username === username)

    if (userExists) {
      toast({
        title: "خطا",
        description: "این نام کاربری قبلاً ثبت شده است",
        variant: "destructive",
      })
      return
    }

    const newUser: User = {
      id: Date.now().toString(),
      username,
      password,
      isAdmin: false,
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("users", JSON.stringify(users))

    toast({
      title: "ثبت نام موفق",
      description: "حساب کاربری شما ایجاد شد",
    })

    setUsername("")
    setPassword("")
    setConfirmPassword("")
  }

  if (isLoading) {
    return <LoadingCube />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/10 backdrop-blur-lg border-purple-300/30">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-white">سایت عناصر</CardTitle>
          <CardDescription className="text-purple-200">وارد شوید یا ثبت نام کنید</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="login" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-purple-800/50">
              <TabsTrigger value="login" className="text-white data-[state=active]:bg-purple-600">
                ورود
              </TabsTrigger>
              <TabsTrigger value="register" className="text-white data-[state=active]:bg-purple-600">
                ثبت نام
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="login-username" className="text-white">
                  نام کاربری
                </Label>
                <Input
                  id="login-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-white/20 border-purple-300/50 text-white placeholder:text-purple-200"
                  placeholder="نام کاربری خود را وارد کنید"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="login-password" className="text-white">
                  رمز عبور
                </Label>
                <Input
                  id="login-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/20 border-purple-300/50 text-white placeholder:text-purple-200"
                  placeholder="رمز عبور خود را وارد کنید"
                />
              </div>
              <Button onClick={handleLogin} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                ورود
              </Button>
            </TabsContent>

            <TabsContent value="register" className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="register-username" className="text-white">
                  نام کاربری
                </Label>
                <Input
                  id="register-username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-white/20 border-purple-300/50 text-white placeholder:text-purple-200"
                  placeholder="نام کاربری مورد نظر"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="register-password" className="text-white">
                  رمز عبور
                </Label>
                <Input
                  id="register-password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-white/20 border-purple-300/50 text-white placeholder:text-purple-200"
                  placeholder="رمز عبور"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-white">
                  تکرار رمز عبور
                </Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="bg-white/20 border-purple-300/50 text-white placeholder:text-purple-200"
                  placeholder="تکرار رمز عبور"
                />
              </div>
              <Button onClick={handleRegister} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                ثبت نام
              </Button>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
