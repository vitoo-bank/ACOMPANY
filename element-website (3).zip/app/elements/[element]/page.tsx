"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Upload, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import LoadingCube from "@/components/loading-cube"

interface User {
  id: string
  username: string
  password: string
  isAdmin: boolean
  createdAt: string
}

interface ImagePost {
  id: string
  title: string
  description: string
  imageUrl: string
  element: string
  createdBy: string
  createdAt: string
}

export default function ElementPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [posts, setPosts] = useState<ImagePost[]>([])
  const [selectedPost, setSelectedPost] = useState<ImagePost | null>(null)
  const [isUploadOpen, setIsUploadOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string>("")

  const router = useRouter()
  const params = useParams()
  const { toast } = useToast()
  const element = params.element as string

  const elementNames: { [key: string]: string } = {
    water: "آب",
    fire: "آتش",
    wind: "باد",
    earth: "خاک",
    "forbidden-art": "هنر ممنوعه",
  }

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      router.push("/")
      return
    }

    const userData = JSON.parse(user)
    setCurrentUser(userData)

    // Check if user can access forbidden art
    if (element === "forbidden-art" && !userData.isAdmin) {
      router.push("/dashboard")
      return
    }

    // Load posts for this element
    const allPosts: ImagePost[] = JSON.parse(localStorage.getItem("posts") || "[]")
    const elementPosts = allPosts.filter((post) => post.element === element)
    setPosts(elementPosts)

    setTimeout(() => setIsLoading(false), 3000)
  }, [router, element])

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setImageFile(file)
      const reader = new FileReader()
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSubmitPost = () => {
    if (!title || !description || !imageFile) {
      toast({
        title: "خطا",
        description: "لطفاً تمام فیلدها را پر کنید",
        variant: "destructive",
      })
      return
    }

    const newPost: ImagePost = {
      id: Date.now().toString(),
      title,
      description,
      imageUrl: imagePreview,
      element,
      createdBy: currentUser!.username,
      createdAt: new Date().toISOString(),
    }

    const allPosts: ImagePost[] = JSON.parse(localStorage.getItem("posts") || "[]")
    allPosts.push(newPost)
    localStorage.setItem("posts", JSON.stringify(allPosts))

    setPosts([...posts, newPost])
    setIsUploadOpen(false)
    setTitle("")
    setDescription("")
    setImageFile(null)
    setImagePreview("")

    toast({
      title: "موفق",
      description: "پست شما با موفقیت اضافه شد",
    })
  }

  const goBack = () => {
    setIsLoading(true)
    setTimeout(() => {
      router.push("/dashboard")
    }, 3000)
  }

  if (isLoading) {
    return <LoadingCube />
  }

  if (!currentUser) {
    return null
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Button
              onClick={goBack}
              variant="outline"
              className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              بازگشت
            </Button>
            <h1 className="text-3xl font-bold text-white">{elementNames[element] || element}</h1>
          </div>

          {currentUser.isAdmin && (
            <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
              <DialogTrigger asChild>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                  <Upload className="w-4 h-4 mr-2" />
                  اضافه کردن عکس
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-purple-900/95 border-purple-300/30 text-white">
                <DialogHeader>
                  <DialogTitle>اضافه کردن عکس جدید</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">عنوان</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="bg-white/20 border-purple-300/50 text-white"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">توضیحات</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="bg-white/20 border-purple-300/50 text-white"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="image">انتخاب عکس</Label>
                    <Input
                      id="image"
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="bg-white/20 border-purple-300/50 text-white"
                    />
                  </div>
                  {imagePreview && (
                    <div className="relative">
                      <img
                        src={imagePreview || "/placeholder.svg"}
                        alt="Preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>
                  )}
                  <Button onClick={handleSubmitPost} className="w-full bg-purple-600 hover:bg-purple-700">
                    اضافه کردن
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Posts Grid */}
        {posts.length === 0 ? (
          <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
            <CardContent className="text-center py-12">
              <p className="text-white text-xl">هنوز هیچ پستی اضافه نشده است</p>
              <p className="text-purple-200 mt-2">
                {currentUser.isAdmin ? "اولین پست را اضافه کنید" : "منتظر اضافه شدن محتوا باشید"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <Card
                key={post.id}
                className="bg-white/10 backdrop-blur-lg border-purple-300/30 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105"
                onClick={() => setSelectedPost(post)}
              >
                <CardHeader className="p-0">
                  <img
                    src={post.imageUrl || "/placeholder.svg"}
                    alt={post.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </CardHeader>
                <CardContent className="p-4">
                  <CardTitle className="text-white mb-2">{post.title}</CardTitle>
                  <p className="text-purple-200 text-sm line-clamp-2">{post.description}</p>
                  <p className="text-purple-300 text-xs mt-2">توسط: {post.createdBy}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Full Screen Modal */}
        {selectedPost && (
          <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
            <DialogContent className="max-w-4xl bg-purple-900/95 border-purple-300/30 text-white">
              <DialogHeader>
                <div className="flex justify-between items-center">
                  <DialogTitle className="text-2xl">{selectedPost.title}</DialogTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedPost(null)}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </DialogHeader>
              <div className="space-y-4">
                <img
                  src={selectedPost.imageUrl || "/placeholder.svg"}
                  alt={selectedPost.title}
                  className="w-full max-h-96 object-contain rounded-lg"
                />
                <div>
                  <h3 className="text-lg font-semibold mb-2">توضیحات:</h3>
                  <p className="text-purple-200 leading-relaxed">{selectedPost.description}</p>
                </div>
                <div className="flex justify-between text-sm text-purple-300">
                  <span>توسط: {selectedPost.createdBy}</span>
                  <span>{new Date(selectedPost.createdAt).toLocaleDateString("fa-IR")}</span>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  )
}
