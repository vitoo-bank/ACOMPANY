"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Droplets, Flame, Wind, Mountain, Palette, Settings, LogOut } from "lucide-react"
import LoadingCube from "@/components/loading-cube"

interface DashboardUser {
  id: string
  username: string
  password: string
  isAdmin: boolean
  createdAt: string
}

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<DashboardUser | null>(null)
  const router = useRouter()

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      router.push("/")
      return
    }

    setCurrentUser(JSON.parse(user))
    setTimeout(() => setIsLoading(false), 3000)
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("currentUser")
    router.push("/")
  }

  const navigateToElement = (element: string) => {
    setIsLoading(true)
    setTimeout(() => {
      router.push(`/elements/${element}`)
    }, 3000)
  }

  const navigateToAdmin = () => {
    setIsLoading(true)
    setTimeout(() => {
      router.push("/admin")
    }, 3000)
  }

  const navigateToProfile = () => {
    setIsLoading(true)
    setTimeout(() => {
      router.push("/profile")
    }, 3000)
  }

  if (isLoading) {
    return <LoadingCube />
  }

  if (!currentUser) {
    return null
  }

  const elements = [
    { name: "آب", key: "water", icon: Droplets, color: "from-blue-500 to-cyan-500" },
    { name: "آتش", key: "fire", icon: Flame, color: "from-red-500 to-orange-500" },
    { name: "باد", key: "wind", icon: Wind, color: "from-gray-400 to-gray-600" },
    { name: "خاک", key: "earth", icon: Mountain, color: "from-amber-600 to-yellow-600" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="text-white">
            <h1 className="text-3xl font-bold">خوش آمدید، {currentUser.username}</h1>
            <p className="text-purple-200">{currentUser.isAdmin ? "مدیر سایت" : "کاربر عادی"}</p>
          </div>
          <div className="flex gap-2">
            <Button
              onClick={navigateToProfile}
              variant="outline"
              className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              پروفایل
            </Button>
            {currentUser.isAdmin && (
              <Button
                onClick={navigateToAdmin}
                variant="outline"
                className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
              >
                <Settings className="w-4 h-4 mr-2" />
                مدیریت
              </Button>
            )}
            <Button
              onClick={handleLogout}
              variant="outline"
              className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
            >
              <LogOut className="w-4 h-4 mr-2" />
              خروج
            </Button>
          </div>
        </div>

        {/* Elements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {elements.map((element) => {
            const IconComponent = element.icon
            return (
              <Card
                key={element.key}
                className="bg-white/10 backdrop-blur-lg border-purple-300/30 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105"
                onClick={() => navigateToElement(element.key)}
              >
                <CardHeader className="text-center">
                  <div
                    className={`w-20 h-20 mx-auto rounded-full bg-gradient-to-r ${element.color} flex items-center justify-center mb-4`}
                  >
                    <IconComponent className="w-10 h-10 text-white" />
                  </div>
                  <CardTitle className="text-2xl text-white">{element.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-purple-200 text-center">کلیک کنید تا وارد بخش {element.name} شوید</p>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Admin Only - Forbidden Art */}
        {currentUser.isAdmin && (
          <Card
            className="bg-gradient-to-r from-red-900/50 to-purple-900/50 backdrop-blur-lg border-red-500/30 hover:bg-red-900/30 transition-all duration-300 cursor-pointer transform hover:scale-105"
            onClick={() => navigateToElement("forbidden-art")}
          >
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-r from-red-500 to-purple-500 flex items-center justify-center mb-4">
                <Palette className="w-10 h-10 text-white" />
              </div>
              <CardTitle className="text-2xl text-white">هنر ممنوعه</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-red-200 text-center">فقط برای مدیران - محتوای ویژه</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
