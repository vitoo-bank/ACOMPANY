"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Users, BarChart3, Edit, Trash2, Shield } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import LoadingCube from "@/components/loading-cube"

interface User {
  id: string
  username: string
  password: string
  isAdmin: boolean
  createdAt: string
}

interface ImagePost {
  id: string
  title: string
  description: string
  imageUrl: string
  element: string
  createdBy: string
  createdAt: string
}

export default function AdminPage() {
  const [isLoading, setIsLoading] = useState(true)
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const [posts, setPosts] = useState<ImagePost[]>([])
  const [editingUser, setEditingUser] = useState<User | null>(null)
  const [newUsername, setNewUsername] = useState("")
  const [newPassword, setNewPassword] = useState("")

  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    const user = localStorage.getItem("currentUser")
    if (!user) {
      router.push("/")
      return
    }

    const userData = JSON.parse(user)
    if (!userData.isAdmin) {
      router.push("/dashboard")
      return
    }

    setCurrentUser(userData)
    loadData()
    setTimeout(() => setIsLoading(false), 3000)
  }, [router])

  const loadData = () => {
    const allUsers: User[] = JSON.parse(localStorage.getItem("users") || "[]")
    const allPosts: ImagePost[] = JSON.parse(localStorage.getItem("posts") || "[]")
    setUsers(allUsers)
    setPosts(allPosts)
  }

  const handleEditUser = (user: User) => {
    setEditingUser(user)
    setNewUsername(user.username)
    setNewPassword(user.password)
  }

  const handleUpdateUser = () => {
    if (!editingUser) return

    const updatedUsers = users.map((user) =>
      user.id === editingUser.id ? { ...user, username: newUsername, password: newPassword } : user,
    )

    localStorage.setItem("users", JSON.stringify(updatedUsers))
    setUsers(updatedUsers)
    setEditingUser(null)

    toast({
      title: "موفق",
      description: "اطلاعات کاربر به‌روزرسانی شد",
    })
  }

  const handleDeleteUser = (userId: string) => {
    if (userId === currentUser?.id) {
      toast({
        title: "خطا",
        description: "نمی‌توانید خودتان را حذف کنید",
        variant: "destructive",
      })
      return
    }

    const updatedUsers = users.filter((user) => user.id !== userId)
    localStorage.setItem("users", JSON.stringify(updatedUsers))
    setUsers(updatedUsers)

    toast({
      title: "موفق",
      description: "کاربر حذف شد",
    })
  }

  const handleToggleAdmin = (userId: string) => {
    if (userId === currentUser?.id) {
      toast({
        title: "خطا",
        description: "نمی‌توانید نقش خودتان را تغییر دهید",
        variant: "destructive",
      })
      return
    }

    const updatedUsers = users.map((user) => (user.id === userId ? { ...user, isAdmin: !user.isAdmin } : user))

    localStorage.setItem("users", JSON.stringify(updatedUsers))
    setUsers(updatedUsers)

    toast({
      title: "موفق",
      description: "نقش کاربر تغییر کرد",
    })
  }

  const goBack = () => {
    setIsLoading(true)
    setTimeout(() => {
      router.push("/dashboard")
    }, 3000)
  }

  if (isLoading) {
    return <LoadingCube />
  }

  if (!currentUser) {
    return null
  }

  const stats = {
    totalUsers: users.length,
    totalAdmins: users.filter((u) => u.isAdmin).length,
    totalPosts: posts.length,
    postsThisMonth: posts.filter((p) => new Date(p.createdAt).getMonth() === new Date().getMonth()).length,
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <Button
              onClick={goBack}
              variant="outline"
              className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              بازگشت
            </Button>
            <h1 className="text-3xl font-bold text-white">پنل مدیریت</h1>
          </div>
        </div>

        <Tabs defaultValue="stats" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-purple-800/50">
            <TabsTrigger value="stats" className="text-white data-[state=active]:bg-purple-600">
              <BarChart3 className="w-4 h-4 mr-2" />
              آمار سایت
            </TabsTrigger>
            <TabsTrigger value="users" className="text-white data-[state=active]:bg-purple-600">
              <Users className="w-4 h-4 mr-2" />
              مدیریت کاربران
            </TabsTrigger>
          </TabsList>

          <TabsContent value="stats" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-purple-200">کل کاربران</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalUsers}</div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-purple-200">مدیران</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalAdmins}</div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-purple-200">کل پست‌ها</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalPosts}</div>
                </CardContent>
              </Card>

              <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-purple-200">پست‌های این ماه</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.postsThisMonth}</div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white/10 backdrop-blur-lg border-purple-300/30">
              <CardHeader>
                <CardTitle className="text-white">آخرین فعالیت‌ها</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {posts
                    .slice(-5)
                    .reverse()
                    .map((post) => (
                      <div key={post.id} className="flex justify-between items-center">
                        <div>
                          <p className="text-white font-medium">{post.title}</p>
                          <p className="text-purple-200 text-sm">
                            توسط {post.createdBy} در بخش {post.element}
                          </p>
                        </div>
                        <span className="text-purple-300 text-sm">
                          {new Date(post.createdAt).toLocaleDateString("fa-IR")}
                        </span>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <div className="grid gap-4">
              {users.map((user) => (
                <Card key={user.id} className="bg-white/10 backdrop-blur-lg border-purple-300/30">
                  <CardContent className="flex justify-between items-center p-6">
                    <div>
                      <h3 className="text-white font-semibold">{user.username}</h3>
                      <p className="text-purple-200 text-sm">
                        {user.isAdmin ? "مدیر" : "کاربر عادی"} - عضو از{" "}
                        {new Date(user.createdAt).toLocaleDateString("fa-IR")}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleEditUser(user)}
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => handleToggleAdmin(user.id)}
                        size="sm"
                        variant="outline"
                        className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
                        disabled={user.id === currentUser?.id}
                      >
                        <Shield className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => handleDeleteUser(user.id)}
                        size="sm"
                        variant="outline"
                        className="bg-red-500/20 border-red-300/50 text-red-200 hover:bg-red-500/30"
                        disabled={user.id === currentUser?.id}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Edit User Dialog */}
        {editingUser && (
          <Dialog open={!!editingUser} onOpenChange={() => setEditingUser(null)}>
            <DialogContent className="bg-purple-900/95 border-purple-300/30 text-white">
              <DialogHeader>
                <DialogTitle>ویرایش کاربر</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-username">نام کاربری</Label>
                  <Input
                    id="edit-username"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    className="bg-white/20 border-purple-300/50 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="edit-password">رمز عبور</Label>
                  <Input
                    id="edit-password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="bg-white/20 border-purple-300/50 text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={handleUpdateUser} className="bg-purple-600 hover:bg-purple-700">
                    ذخیره تغییرات
                  </Button>
                  <Button
                    onClick={() => setEditingUser(null)}
                    variant="outline"
                    className="bg-white/10 border-purple-300/50 text-white hover:bg-white/20"
                  >
                    لغو
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  )
}
